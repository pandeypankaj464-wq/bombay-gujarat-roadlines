package com.bgr.transport;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private final String navy="#101D36", blue="#1D3F72", gold="#D5A83B", pale="#F3F6FA";
    private LinearLayout root, list; private TextView count, freightTotal, title; private JSONArray bookings;
    private boolean hindi=false;
    private android.content.SharedPreferences prefs;
    public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(Color.parseColor(navy)); getWindow().setNavigationBarColor(Color.parseColor(navy)); prefs=getSharedPreferences("bgr",0); load(); render();}
    private void load(){try{bookings=new JSONArray(prefs.getString("bookings","[]"));}catch(Exception e){bookings=new JSONArray();}}
    private void save(){prefs.edit().putString("bookings",bookings.toString()).apply();}
    private int c(String s){return Color.parseColor(s);} 
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(c(color));if(bold)t.setTypeface(null,Typeface.BOLD);t.setPadding(0,4,0,4);return t;}
    private LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private GradientDrawable bg(String color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(c(color));d.setCornerRadius(radius);return d;}
    private Button button(String label){Button b=new Button(this);b.setText(label);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setBackground(bg(blue,18));return b;}
    private void render(){
        root=column();root.setBackgroundColor(c(pale)); ScrollView scroll=new ScrollView(this);scroll.addView(root);setContentView(scroll);
        LinearLayout header=column();header.setPadding(20,22,20,18);header.setBackground(bg(navy,0));
        LinearLayout top=row();title=text("BOMBAY GUJARAT ROADLINES",19,"#FFFFFF",true);top.addView(title,new LinearLayout.LayoutParams(0,-2,1));Button lang=button(hindi?"English":"हिन्दी");lang.setTextSize(12);top.addView(lang);lang.setOnClickListener(v->{hindi=!hindi;render();});header.addView(top);header.addView(text("TRANSPORT & LOGISTICS MANAGEMENT",11,"#D5A83B",true));root.addView(header);
        LinearLayout body=column();body.setPadding(16,16,16,24);root.addView(body);
        body.addView(text(hindi?"डैशबोर्ड":"Dashboard",21,navy,true));
        LinearLayout stats=row(); stats.setPadding(0,8,0,12);body.addView(stats);
        int total=bookings.length();double freight=0;for(int i=0;i<total;i++)freight+=bookings.optJSONObject(i).optDouble("freight",0);
        stats.addView(statCard(hindi?"कुल बुकिंग":"Total Bookings",String.valueOf(total)),new LinearLayout.LayoutParams(0,104,1));
        View gap=new View(this);stats.addView(gap,new LinearLayout.LayoutParams(10,1));stats.addView(statCard(hindi?"कुल भाड़ा":"Total Freight",String.format(Locale.US,"₹%.0f",freight)),new LinearLayout.LayoutParams(0,104,1));
        Button add=button(hindi?"+ नई बुकिंग जोड़ें":"+ Add New Booking");body.addView(add);add.setOnClickListener(v->showBookingDialog());
        body.addView(text(hindi?"हाल की बुकिंग":"Recent Bookings",18,navy,true));
        list=column();body.addView(list);refreshList();
        body.addView(text("Offline storage • Data stays on this phone",11,"#667085",false));
    }
    private LinearLayout statCard(String label,String value){LinearLayout box=column();box.setPadding(14,12,10,10);box.setBackground(bg("#FFFFFF",18));box.addView(text(label,12,"#667085",false));box.addView(text(value,21,navy,true));return box;}
    private void refreshList(){list.removeAllViews();if(bookings.length()==0){list.addView(text(hindi?"अभी कोई बुकिंग नहीं है।":"No bookings yet. Add your first booking.",14,"#667085",false));return;}for(int i=bookings.length()-1;i>=0;i--){JSONObject o=bookings.optJSONObject(i);LinearLayout card=column();card.setPadding(14,12,14,12);card.setBackground(bg("#FFFFFF",16));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,6,0,6);list.addView(card,lp);card.addView(text(o.optString("truck","Truck not set")+"  •  "+o.optString("date",""),16,navy,true));card.addView(text(o.optString("from","")+"  →  "+o.optString("to",""),14,blue,true));card.addView(text(o.optString("customer","")+"  |  ₹"+o.optString("freight","0"),13,"#667085",false));}}
    private EditText field(LinearLayout box,String hint,int input){EditText e=new EditText(this);e.setSingleLine(true);e.setHint(hint);e.setInputType(input);e.setTextSize(15);box.addView(e,new LinearLayout.LayoutParams(-1,-2));return e;}
    private void showBookingDialog(){LinearLayout form=column();form.setPadding(18,4,18,4);EditText truck=field(form,hindi?"ट्रक नंबर":"Truck number", android.text.InputType.TYPE_CLASS_TEXT);EditText customer=field(form,hindi?"ग्राहक का नाम":"Customer name",android.text.InputType.TYPE_CLASS_TEXT);EditText owner=field(form,hindi?"ट्रक मालिक":"Truck owner",android.text.InputType.TYPE_CLASS_TEXT);EditText from=field(form,hindi?"कहाँ से":"From",android.text.InputType.TYPE_CLASS_TEXT);EditText to=field(form,hindi?"कहाँ तक":"To",android.text.InputType.TYPE_CLASS_TEXT);EditText freight=field(form,hindi?"भाड़ा (₹)":"Freight (₹)",android.text.InputType.TYPE_CLASS_NUMBER|android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        ScrollView sc=new ScrollView(this);sc.addView(form);new AlertDialog.Builder(this).setTitle(hindi?"नई बुकिंग":"New Booking").setView(sc).setNegativeButton(hindi?"रद्द":"Cancel",null).setPositiveButton(hindi?"सेव करें":"Save",(d,w)->{JSONObject o=new JSONObject();try{o.put("truck",truck.getText().toString());o.put("customer",customer.getText().toString());o.put("owner",owner.getText().toString());o.put("from",from.getText().toString());o.put("to",to.getText().toString());o.put("freight",freight.getText().toString().trim().isEmpty()?0:Double.parseDouble(freight.getText().toString()));o.put("date",new SimpleDateFormat("dd MMM yyyy",Locale.getDefault()).format(new Date()));bookings.put(o);save();render();}catch(Exception ex){Toast.makeText(this,"Could not save booking",Toast.LENGTH_SHORT).show();}}).show();}
}
